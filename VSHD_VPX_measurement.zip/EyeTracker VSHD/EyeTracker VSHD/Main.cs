﻿using System.Numerics;
using System.Runtime.InteropServices;

namespace EyeTracker_VSHD;

class EyeTracker
{

    static void Main()
    {
        ViewPointVSHD et = new();
        et.Launch();
        et.Measure();
        et.Close();
    }
}
